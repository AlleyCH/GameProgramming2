using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.XR;

public class GuardFSM : MonoBehaviour
{
    public enum GuardState
    {
        Patrol, Chase, Attack, RunAway
    }
    public GuardState currentState;
    public GameObject enemy;
    public float GuardFOV = 89; //degrees
    private float cosGuardFOVover2InRAD;

    public float closeEnoughCutoff = 5; //if (d(G,E) <=5 m) => close enough
    // Start is called before the first frame update
    void Start()
    {
        cosGuardFOVover2InRAD=Mathf.Cos(GuardFOV/2f*Mathf.Deg2Rad); //in Rad

    }

    // Update is called once per frame
    void Update()
    {
        FSM();

    }

    private void FSM()
    {
        switch (currentState)
        {
            case GuardState.Patrol:
                HandlePatrol();
                break;
            case GuardState.Chase:
                HandleChase();
                break;
            case GuardState.Attack:
                HandleAttack();
                break;
            case GuardState.RunAway:
                HandleRunAway();
                break;
            default:
                break;

        }
    }

    private void HandleRunAway()
    {
        throw new NotImplementedException();
    }

    private void HandleAttack()
    {
        throw new NotImplementedException();
    }

    private void HandleChase()
    {
        throw new NotImplementedException();
    }

    private void HandlePatrol()
    {
        if (SenseEnemy())
        {
            ChangeState(GuardState.Chase);
        }
        //throw new NotImplementedException();

    }

    private void ChangeState(GuardState newGuardState)
    {
        currentState = newGuardState;
    }

    private bool SenseEnemy()
    {
        
        //Case1: Enemy in front and close enough
        if(EnemyInFront() && EnemyCloseEnough()){
            return true;
        } else { 
            return false;
        }

        
        //Case2: Guard hears the enemy footsteps

        //...

        //CaseN: Smells the enemy
    }

    private bool EnemyCloseEnough()
    {
        //throw new NotImplementedException();
        if(Vector3.Distance(this.transform.position, enemy.transform.position) <= closeEnoughCutoff)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private bool EnemyInFront()
    {
        //Angle(Guard.Fwd, E.heading) < GuardFOV/2 => true, else false
        // <=> cos(angle)>cos(Guardfov/2)
        //throw new NotImplementedException();
        //E.heading = (E - G).
        Vector3 enemyHeading=(enemy.transform.position- this.transform.position).normalized;
        //if(Vector3.Angle(enemyHeading, this.transform.forward))
        //{
        //    return true;
        //}
        float cosAngle=Vector3.Dot(enemyHeading, this.transform.forward);
        if( cosAngle> cosGuardFOVover2InRAD)
        {
            return true;
        }
        else
        {
            return false;
        }

    }
}
